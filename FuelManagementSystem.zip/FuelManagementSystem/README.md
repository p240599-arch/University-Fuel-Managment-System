# University Fuel Management System

A JavaFX desktop application for managing university fleet vehicles, drivers, fuel records, and trip logs.

## Screenshots

> Login → Dashboard → Vehicle/Driver/Fuel/Trip management → Reports

## Features

- **Admin Authentication** — secure login (admin / pass123)
- **Dashboard** — live stat cards + fleet overview table
- **Vehicle Management** — add vehicles, assign drivers, track fuel capacity
- **Driver Management** — add/remove drivers, assign to vehicles
- **Fuel Records** — log fuel top-ups per vehicle with date and capacity validation
- **Trip Logs** — record and edit trips (from/to/distance)
- **Reports** — generate full fleet fuel consumption report

## Tech Stack

- **Java 17+**
- **JavaFX 21** (GUI)
- No external libraries required beyond JavaFX SDK

---

## How to Compile & Run

### Option A — VS Code (recommended, matches your screenshot)

1. Install [Extension Pack for Java](https://marketplace.visualstudio.com/items?itemName=vscjava.vscode-java-pack)
2. Install [JavaFX](https://gluonhq.com/products/javafx/) — download SDK, extract to e.g. `C:\javafx-sdk-21`
3. Open the `FuelManagementSystem` folder in VS Code
4. Edit `.vscode/launch.json` — add VM args:
```json
"vmArgs": "--module-path C:\\javafx-sdk-21\\lib --add-modules javafx.controls,javafx.fxml"
```
5. Press **F5** to run

### Option B — Command Line (any OS)

```bash
# 1. Set your JavaFX path
export JAVAFX_HOME=/path/to/javafx-sdk-21

# 2. Compile all files
javac --module-path $JAVAFX_HOME/lib \
      --add-modules javafx.controls \
      -d out \
      src/models/*.java src/views/*.java src/MainApp.java

# 3. Run
java --module-path $JAVAFX_HOME/lib \
     --add-modules javafx.controls \
     -cp out MainApp
```

### Option C — IntelliJ IDEA

1. Open project → File → Project Structure → Libraries → Add JavaFX lib folder
2. Edit Run Configuration → VM Options:
   ```
   --module-path /path/to/javafx-sdk/lib --add-modules javafx.controls
   ```
3. Run `MainApp`

---

## Project Structure

```
FuelManagementSystem/
├── src/
│   ├── MainApp.java           ← Entry point
│   ├── models/
│   │   ├── ADMIN.java
│   │   ├── DRIVER.java
│   │   ├── FUEL_RECORD.java
│   │   ├── TRIP.java
│   │   └── VEHICLE.java
│   └── views/
│       ├── LoginScreen.java
│       ├── MainLayout.java
│       ├── DashboardView.java
│       ├── VehicleView.java
│       ├── DriverView.java
│       ├── FuelView.java
│       ├── TripView.java
│       └── ReportView.java
└── README.md
```

## Default Login

| Field    | Value    |
|----------|----------|
| Username | admin    |
| Password | pass123  |

---

## Design Patterns Used (for Assignment Part 2)

| Pattern | Where Used | Problem Solved |
|---------|-----------|----------------|
| **MVC** | models/ vs views/ separation | Separates data from UI — ADMIN/VEHICLE/DRIVER are pure data; views only display |
| **Singleton** | `LoginScreen.SYSTEM_ADMIN` | Single admin instance shared across all views |
| **Observer** | `TableView.getItems().setAll()` | JavaFX observable list auto-refreshes table when data changes |
| **Facade** | `ADMIN` class | Provides a single interface to manage vehicles, drivers, fuel, reports |

---

## Uploading to GitHub

See instructions below.
