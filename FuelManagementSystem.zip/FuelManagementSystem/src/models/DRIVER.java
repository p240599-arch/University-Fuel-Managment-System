package models;

public class DRIVER {
    private int driverID;
    private String name;
    private String licenseNumber;

    public DRIVER(int driverID, String name, String licenseNumber) {
        this.driverID      = driverID;
        this.name          = name;
        this.licenseNumber = licenseNumber;
    }

    public int getDriverID()         { return driverID; }
    public String getName()          { return name; }
    public String getLicenseNumber() { return licenseNumber; }

    public void recordFuelUsage(int vehicleID, float fuelAmount) {
        System.out.println("[DRIVER] " + name + " recorded fuel usage → Vehicle ID: "
                + vehicleID + " | Amount: " + fuelAmount + "L");
    }

    public void updateTrip(TRIP t) {
        System.out.println("[DRIVER] " + name + " updated trip: " + t);
        t.updateTrip();
    }

    @Override
    public String toString() {
        return "DriverID=" + driverID + ", Name=" + name + ", License=" + licenseNumber;
    }
}
