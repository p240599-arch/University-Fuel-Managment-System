package models;

import java.util.ArrayList;
import java.util.List;

public class VEHICLE {
    private int vehicleID;
    private String vehicleNumber;
    private String vehicleType;
    private float fuelCapacity;

    private List<FUEL_RECORD> fuelRecords;
    private List<TRIP> trips;
    private DRIVER assignedDriver;

    public VEHICLE(int vehicleID, String vehicleNumber, String vehicleType, float fuelCapacity) {
        this.vehicleID     = vehicleID;
        this.vehicleNumber = vehicleNumber;
        this.vehicleType   = vehicleType;
        this.fuelCapacity  = fuelCapacity;
        this.fuelRecords   = new ArrayList<>();
        this.trips         = new ArrayList<>();
    }

    public int getVehicleID()        { return vehicleID; }
    public String getVehicleNumber() { return vehicleNumber; }
    public String getVehicleType()   { return vehicleType; }
    public float getFuelCapacity()   { return fuelCapacity; }
    public DRIVER getAssignedDriver(){ return assignedDriver; }
    public List<FUEL_RECORD> getFuelRecords() { return fuelRecords; }
    public List<TRIP> getTrips()     { return trips; }

    public void assignDriver(DRIVER d) {
        this.assignedDriver = d;
    }

    public String viewVehicleDetails() {
        String driverInfo = (assignedDriver != null) ? assignedDriver.getName() : "None";
        return "Vehicle[ID=" + vehicleID + ", Number=" + vehicleNumber
                + ", Type=" + vehicleType + ", FuelCapacity=" + fuelCapacity + "L"
                + ", AssignedDriver=" + driverInfo + "]";
    }

    public void addFuelRecord(FUEL_RECORD fr) {
        fuelRecords.add(fr);
    }

    public void addTrip(TRIP t) {
        trips.add(t);
    }

    public float getTotalFuelUsed() {
        float total = 0;
        for (FUEL_RECORD fr : fuelRecords) total += fr.getFuelAmount();
        return total;
    }

    @Override
    public String toString() {
        return vehicleNumber + " (" + vehicleType + ")";
    }
}
