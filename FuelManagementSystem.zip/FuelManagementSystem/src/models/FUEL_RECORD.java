package models;

public class FUEL_RECORD {
    private int recordID;
    private float fuelAmount;
    private String date;

    public FUEL_RECORD(int recordID, float fuelAmount, String date) {
        this.recordID = recordID;
        this.fuelAmount = fuelAmount;
        this.date = date;
    }

    public int getRecordID()     { return recordID; }
    public float getFuelAmount() { return fuelAmount; }
    public String getDate()      { return date; }

    public void addFuelRecord(int vehicleID, float fuelAmount) {
        System.out.println("[FUEL_RECORD] Fuel record added for Vehicle ID: " + vehicleID
                + " | Amount: " + fuelAmount + "L | Date: " + this.date);
    }

    public void viewFuelHistory(int vehicleID) {
        System.out.println("[FUEL_RECORD] Record ID: " + recordID
                + " | Vehicle ID: " + vehicleID
                + " | Fuel: " + fuelAmount + "L | Date: " + date);
    }

    @Override
    public String toString() {
        return "RecordID=" + recordID + ", Fuel=" + fuelAmount + "L, Date=" + date;
    }
}
