package models;

public class TRIP {
    private int tripID;
    private String startLocation;
    private String destination;
    private float distance;

    public TRIP(int tripID, String startLocation, String destination, float distance) {
        this.tripID        = tripID;
        this.startLocation = startLocation;
        this.destination   = destination;
        this.distance      = distance;
    }

    public int getTripID()            { return tripID; }
    public String getStartLocation()  { return startLocation; }
    public String getDestination()    { return destination; }
    public float getDistance()        { return distance; }

    public void setStartLocation(String s) { this.startLocation = s; }
    public void setDestination(String d)   { this.destination = d; }
    public void setDistance(float d)       { this.distance = d; }

    public void recordTrip() {
        System.out.println("[TRIP] Trip recorded → ID: " + tripID
                + " | " + startLocation + " → " + destination
                + " | Distance: " + distance + "km");
    }

    public void updateTrip() {
        System.out.println("[TRIP] Trip updated → ID: " + tripID
                + " | " + startLocation + " → " + destination
                + " | Distance: " + distance + "km");
    }

    @Override
    public String toString() {
        return "TripID=" + tripID + ", " + startLocation + " → " + destination + ", " + distance + "km";
    }
}
