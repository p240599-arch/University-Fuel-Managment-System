package views;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import models.ADMIN;

public class MainLayout {

    private final Stage stage;
    private final ADMIN admin;
    private BorderPane root;
    private StackPane contentArea;
    private Label pageTitle;

    public MainLayout(Stage stage, ADMIN admin) {
        this.stage = stage;
        this.admin = admin;
    }

    public void show() {
        stage.setTitle("UniFleet — " + admin.getUsername());

        root = new BorderPane();
        root.setStyle("-fx-background-color: #0D1117;");

        root.setLeft(buildSidebar());
        root.setTop(buildTopBar());

        contentArea = new StackPane();
        contentArea.setStyle("-fx-background-color: #0D1117;");
        root.setCenter(contentArea);

        showPage("dashboard");

        Scene scene = new Scene(root, 1100, 680);
        stage.setScene(scene);
        stage.show();
    }

    private VBox buildSidebar() {
        VBox sidebar = new VBox(0);
        sidebar.setPrefWidth(210);
        sidebar.setStyle("-fx-background-color: #161B22; -fx-border-color: #30363D; -fx-border-width: 0 1 0 0;");

        // Logo
        VBox logo = new VBox(4);
        logo.setPadding(new Insets(24, 20, 20, 20));
        logo.setStyle("-fx-border-color: #30363D; -fx-border-width: 0 0 1 0;");
        Label logoIcon = new Label("⛽ UniFleet");
        logoIcon.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #F0A500; -fx-font-family: 'Courier New';");
        Label logoSub = new Label("Fleet Management");
        logoSub.setStyle("-fx-font-size: 10px; -fx-text-fill: #484F58; -fx-font-family: 'Courier New';");
        logo.getChildren().addAll(logoIcon, logoSub);

        VBox nav = new VBox(2);
        nav.setPadding(new Insets(16, 8, 16, 8));
        VBox.setVgrow(nav, Priority.ALWAYS);

        addNavSection(nav, "OVERVIEW");
        Button dashBtn  = navBtn("📊  Dashboard",  "dashboard",  nav);
        nav.getChildren().add(dashBtn);

        addNavSection(nav, "FLEET");
        Button vehBtn   = navBtn("🚗  Vehicles",   "vehicles",   nav);
        Button drvBtn   = navBtn("👤  Drivers",    "drivers",    nav);
        nav.getChildren().addAll(vehBtn, drvBtn);

        addNavSection(nav, "OPERATIONS");
        Button fuelBtn  = navBtn("⛽  Fuel Records","fuel",       nav);
        Button tripBtn  = navBtn("🗺  Trips",       "trips",      nav);
        nav.getChildren().addAll(fuelBtn, tripBtn);

        addNavSection(nav, "REPORTS");
        Button repBtn   = navBtn("📄  Reports",    "reports",    nav);
        nav.getChildren().add(repBtn);

        // Logout at bottom
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        Button logoutBtn = new Button("⏻  Logout");
        logoutBtn.setPrefWidth(Double.MAX_VALUE);
        logoutBtn.setStyle(
            "-fx-background-color: transparent; -fx-text-fill: #F85149; " +
            "-fx-font-family: 'Courier New'; -fx-font-size: 12px; " +
            "-fx-alignment: CENTER_LEFT; -fx-padding: 10 12; -fx-cursor: hand; -fx-background-radius: 6;"
        );
        logoutBtn.setOnMouseEntered(e -> logoutBtn.setStyle(
            "-fx-background-color: rgba(248,81,73,0.1); -fx-text-fill: #F85149; " +
            "-fx-font-family: 'Courier New'; -fx-font-size: 12px; " +
            "-fx-alignment: CENTER_LEFT; -fx-padding: 10 12; -fx-cursor: hand; -fx-background-radius: 6;"
        ));
        logoutBtn.setOnMouseExited(e -> logoutBtn.setStyle(
            "-fx-background-color: transparent; -fx-text-fill: #F85149; " +
            "-fx-font-family: 'Courier New'; -fx-font-size: 12px; " +
            "-fx-alignment: CENTER_LEFT; -fx-padding: 10 12; -fx-cursor: hand; -fx-background-radius: 6;"
        ));
        logoutBtn.setOnAction(e -> {
            Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Log out?", ButtonType.YES, ButtonType.NO);
            a.setHeaderText("Confirm Logout");
            a.showAndWait().ifPresent(bt -> { if (bt == ButtonType.YES) new LoginScreen(stage).show(); });
        });

        nav.getChildren().addAll(spacer, logoutBtn);
        sidebar.getChildren().addAll(logo, nav);
        return sidebar;
    }

    private HBox buildTopBar() {
        HBox topBar = new HBox();
        topBar.setPadding(new Insets(0, 24, 0, 24));
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setPrefHeight(52);
        topBar.setStyle("-fx-background-color: #161B22; -fx-border-color: #30363D; -fx-border-width: 0 0 1 0;");

        pageTitle = new Label("DASHBOARD");
        pageTitle.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: #E6EDF3; -fx-font-family: 'Courier New'; -fx-letter-spacing: 2;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label adminBadge = new Label("ADMIN: " + admin.getUsername().toUpperCase());
        adminBadge.setStyle(
            "-fx-background-color: rgba(240,165,0,0.15); -fx-border-color: rgba(240,165,0,0.35); " +
            "-fx-border-radius: 4; -fx-background-radius: 4; " +
            "-fx-text-fill: #F0A500; -fx-font-family: 'Courier New'; -fx-font-size: 11px; -fx-padding: 4 10;"
        );

        topBar.getChildren().addAll(pageTitle, spacer, adminBadge);
        return topBar;
    }

    private void addNavSection(VBox nav, String title) {
        Label sec = new Label(title);
        sec.setStyle("-fx-font-size: 9px; -fx-text-fill: #484F58; -fx-font-family: 'Courier New'; -fx-padding: 12 12 4 12; -fx-letter-spacing: 2;");
        nav.getChildren().add(sec);
    }

    private Button navBtn(String text, String page, VBox nav) {
        Button btn = new Button(text);
        btn.setPrefWidth(Double.MAX_VALUE);
        styleNavBtn(btn, false);
        btn.setOnAction(e -> {
            nav.getChildren().stream()
               .filter(n -> n instanceof Button)
               .forEach(n -> styleNavBtn((Button) n, false));
            styleNavBtn(btn, true);
            showPage(page);
        });
        return btn;
    }

    void styleNavBtn(Button btn, boolean active) {
        if (active) btn.setStyle(
            "-fx-background-color: rgba(240,165,0,0.12); -fx-text-fill: #F0A500; " +
            "-fx-font-family: 'Courier New'; -fx-font-size: 12px; " +
            "-fx-alignment: CENTER_LEFT; -fx-padding: 9 12; -fx-cursor: hand; -fx-background-radius: 6; " +
            "-fx-border-color: #F0A500; -fx-border-width: 0 0 0 2; -fx-border-radius: 0;"
        );
        else btn.setStyle(
            "-fx-background-color: transparent; -fx-text-fill: #8B949E; " +
            "-fx-font-family: 'Courier New'; -fx-font-size: 12px; " +
            "-fx-alignment: CENTER_LEFT; -fx-padding: 9 12; -fx-cursor: hand; -fx-background-radius: 6;"
        );
        btn.setOnMouseEntered(e -> { if (!btn.getStyle().contains("#F0A500") || btn.getStyle().contains("#8B949E"))
            btn.setStyle(btn.getStyle().replace("-fx-text-fill: #8B949E", "-fx-text-fill: #E6EDF3")
                                       .replace("-fx-background-color: transparent", "-fx-background-color: #21262D")); });
        btn.setOnMouseExited(e -> { if (!active) styleNavBtn(btn, false); });
    }

    public void showPage(String page) {
        contentArea.getChildren().clear();
        switch (page) {
            case "dashboard" -> { pageTitle.setText("DASHBOARD");     contentArea.getChildren().add(new DashboardView(admin, this).build()); }
            case "vehicles"  -> { pageTitle.setText("VEHICLES");      contentArea.getChildren().add(new VehicleView(admin).build()); }
            case "drivers"   -> { pageTitle.setText("DRIVERS");       contentArea.getChildren().add(new DriverView(admin).build()); }
            case "fuel"      -> { pageTitle.setText("FUEL RECORDS");  contentArea.getChildren().add(new FuelView(admin).build()); }
            case "trips"     -> { pageTitle.setText("TRIPS");         contentArea.getChildren().add(new TripView(admin).build()); }
            case "reports"   -> { pageTitle.setText("REPORTS");       contentArea.getChildren().add(new ReportView(admin).build()); }
        }
    }

    public ADMIN getAdmin() { return admin; }
}
