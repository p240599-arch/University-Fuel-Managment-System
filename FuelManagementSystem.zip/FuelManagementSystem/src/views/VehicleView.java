package views;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import models.*;

import java.util.Optional;

public class VehicleView {

    private final ADMIN admin;
    private TableView<VEHICLE> table;
    private int nextID = 200;

    public VehicleView(ADMIN admin) { this.admin = admin; }

    public ScrollPane build() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(28));
        content.setStyle("-fx-background-color: #0D1117;");

        // Header row
        HBox header = new HBox(12);
        header.setAlignment(Pos.CENTER_LEFT);
        Label title = sectionLabel("VEHICLE REGISTRY");
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
        Button addBtn = primaryBtn("+ Add Vehicle");
        addBtn.setOnAction(e -> showAddDialog());
        header.getChildren().addAll(title, spacer, addBtn);

        // Table
        table = new TableView<>();
        DashboardView.styleTable(table);
        table.setPrefHeight(460);

        TableColumn<VEHICLE, String> idCol   = DashboardView.col("ID",           80,  v -> String.valueOf(v.getVehicleID()));
        TableColumn<VEHICLE, String> numCol  = DashboardView.col("Registration", 150, v -> v.getVehicleNumber());
        TableColumn<VEHICLE, String> typeCol = DashboardView.col("Type",         90,  v -> v.getVehicleType());
        TableColumn<VEHICLE, String> capCol  = DashboardView.col("Capacity",     100, v -> v.getFuelCapacity() + "L");
        TableColumn<VEHICLE, String> drvCol  = DashboardView.col("Driver",       160, v -> v.getAssignedDriver() != null ? v.getAssignedDriver().getName() : "Unassigned");
        TableColumn<VEHICLE, String> fuelCol = DashboardView.col("Fuel Used",    110, v -> String.format("%.1fL", v.getTotalFuelUsed()));

        TableColumn<VEHICLE, Void> actCol = new TableColumn<>("Actions");
        actCol.setPrefWidth(160);
        actCol.setCellFactory(col -> new TableCell<>() {
            final Button assign = smallBtn("Assign Driver");
            final Button del    = dangerBtn("Remove");
            { HBox box = new HBox(6, assign, del); box.setAlignment(Pos.CENTER);
              assign.setOnAction(e -> showAssignDialog(getTableView().getItems().get(getIndex())));
              del.setOnAction(e -> {
                  VEHICLE v = getTableView().getItems().get(getIndex());
                  Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Remove " + v.getVehicleNumber() + "?", ButtonType.YES, ButtonType.NO);
                  a.showAndWait().ifPresent(bt -> { if (bt == ButtonType.YES) { admin.removeVehicle(v); refresh(); } });
              });
              setGraphic(box); }
            @Override protected void updateItem(Void item, boolean empty) { super.updateItem(item, empty); setGraphic(empty ? null : getGraphic()); }
        });

        table.getColumns().addAll(idCol, numCol, typeCol, capCol, drvCol, fuelCol, actCol);
        refresh();

        content.getChildren().addAll(header, table);
        ScrollPane sp = new ScrollPane(content);
        sp.setFitToWidth(true);
        sp.setStyle("-fx-background-color: #0D1117; -fx-background: #0D1117;");
        return sp;
    }

    private void refresh() {
        table.getItems().setAll(admin.getVehicles());
    }

    private void showAddDialog() {
        Dialog<ButtonType> dlg = styledDialog("Add Vehicle");
        GridPane grid = formGrid();

        TextField numF  = formField("UNI-XXX-00");
        ComboBox<String> typeF = new ComboBox<>();
        typeF.getItems().addAll("Bus", "Van", "Car", "Truck");
        typeF.setValue("Car");
        styleCombo(typeF);
        TextField capF  = formField("60");

        grid.addRow(0, formLabel("Registration"), numF);
        grid.addRow(1, formLabel("Type"), typeF);
        grid.addRow(2, formLabel("Capacity (L)"), capF);

        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        styleDialogButtons(dlg);

        Optional<ButtonType> res = dlg.showAndWait();
        if (res.isPresent() && res.get() == ButtonType.OK) {
            String num = numF.getText().trim();
            String type = typeF.getValue();
            String capStr = capF.getText().trim();
            if (num.isEmpty() || capStr.isEmpty()) { showError("All fields required."); return; }
            try {
                float cap = Float.parseFloat(capStr);
                admin.addVehicle(new VEHICLE(nextID++, num, type, cap));
                refresh();
            } catch (NumberFormatException ex) { showError("Capacity must be a number."); }
        }
    }

    private void showAssignDialog(VEHICLE v) {
        if (admin.getDrivers().isEmpty()) { showError("No drivers registered yet."); return; }
        ChoiceDialog<DRIVER> dlg = new ChoiceDialog<>(admin.getDrivers().get(0), admin.getDrivers());
        dlg.setTitle("Assign Driver");
        dlg.setHeaderText("Assign a driver to " + v.getVehicleNumber());
        dlg.setContentText("Select Driver:");
        styleAlertDialog(dlg);
        dlg.showAndWait().ifPresent(d -> { v.assignDriver(d); refresh(); });
    }

    // ── shared helpers ──────────────────────────────────────────────
    static Dialog<ButtonType> styledDialog(String title) {
        Dialog<ButtonType> dlg = new Dialog<>();
        dlg.setTitle(title);
        dlg.setHeaderText(null);
        dlg.getDialogPane().setStyle("-fx-background-color: #161B22; -fx-border-color: #30363D;");
        return dlg;
    }

    static GridPane formGrid() {
        GridPane g = new GridPane();
        g.setHgap(12); g.setVgap(14);
        g.setPadding(new Insets(20));
        ColumnConstraints c1 = new ColumnConstraints(120), c2 = new ColumnConstraints(220);
        g.getColumnConstraints().addAll(c1, c2);
        return g;
    }

    static Label formLabel(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-font-size: 11px; -fx-text-fill: #8B949E; -fx-font-family: 'Courier New';");
        return l;
    }

    static TextField formField(String prompt) {
        TextField tf = new TextField();
        tf.setPromptText(prompt);
        tf.setStyle("-fx-background-color: #0D1117; -fx-border-color: #30363D; -fx-border-radius: 5; " +
                    "-fx-background-radius: 5; -fx-text-fill: #E6EDF3; -fx-font-family: 'Courier New'; " +
                    "-fx-font-size: 12px; -fx-padding: 6 10;");
        return tf;
    }

    static void styleCombo(ComboBox<?> cb) {
        cb.setStyle("-fx-background-color: #0D1117; -fx-border-color: #30363D; -fx-border-radius: 5; " +
                    "-fx-background-radius: 5; -fx-text-fill: #E6EDF3; -fx-font-family: 'Courier New'; -fx-font-size: 12px;");
        cb.setPrefWidth(220);
    }

    static void styleDialogButtons(Dialog<?> dlg) {
        dlg.getDialogPane().lookupButton(ButtonType.OK).setStyle(
            "-fx-background-color: #F0A500; -fx-text-fill: #0D1117; -fx-font-weight: bold; " +
            "-fx-font-family: 'Courier New'; -fx-font-size: 12px; -fx-background-radius: 5; -fx-cursor: hand;");
        dlg.getDialogPane().lookupButton(ButtonType.CANCEL).setStyle(
            "-fx-background-color: #21262D; -fx-text-fill: #8B949E; " +
            "-fx-font-family: 'Courier New'; -fx-font-size: 12px; -fx-background-radius: 5; -fx-cursor: hand;");
    }

    static void styleAlertDialog(Dialog<?> dlg) {
        dlg.getDialogPane().setStyle("-fx-background-color: #161B22; -fx-border-color: #30363D;");
    }

    static Label sectionLabel(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-font-size: 11px; -fx-font-weight: bold; -fx-text-fill: #8B949E; -fx-font-family: 'Courier New'; -fx-letter-spacing: 2;");
        return l;
    }

    static Button primaryBtn(String text) {
        Button b = new Button(text);
        b.setStyle("-fx-background-color: #F0A500; -fx-text-fill: #0D1117; -fx-font-weight: bold; " +
                   "-fx-font-family: 'Courier New'; -fx-font-size: 12px; -fx-background-radius: 6; " +
                   "-fx-padding: 8 16; -fx-cursor: hand;");
        return b;
    }

    static Button smallBtn(String text) {
        Button b = new Button(text);
        b.setStyle("-fx-background-color: #21262D; -fx-border-color: #30363D; -fx-border-radius: 4; " +
                   "-fx-background-radius: 4; -fx-text-fill: #E6EDF3; " +
                   "-fx-font-family: 'Courier New'; -fx-font-size: 10px; -fx-padding: 4 8; -fx-cursor: hand;");
        return b;
    }

    static Button dangerBtn(String text) {
        Button b = new Button(text);
        b.setStyle("-fx-background-color: transparent; -fx-border-color: rgba(248,81,73,0.4); -fx-border-radius: 4; " +
                   "-fx-background-radius: 4; -fx-text-fill: #F85149; " +
                   "-fx-font-family: 'Courier New'; -fx-font-size: 10px; -fx-padding: 4 8; -fx-cursor: hand;");
        return b;
    }

    static void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        a.setHeaderText("Error");
        styleAlertDialog(a);
        a.showAndWait();
    }
}
