package views;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import models.*;

import java.util.Optional;

public class DriverView {

    private final ADMIN admin;
    private TableView<DRIVER> table;
    private int nextID = 300;

    public DriverView(ADMIN admin) { this.admin = admin; }

    public ScrollPane build() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(28));
        content.setStyle("-fx-background-color: #0D1117;");

        HBox header = new HBox(12);
        header.setAlignment(Pos.CENTER_LEFT);
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
        Button addBtn = VehicleView.primaryBtn("+ Add Driver");
        addBtn.setOnAction(e -> showAddDialog());
        header.getChildren().addAll(VehicleView.sectionLabel("DRIVER REGISTRY"), spacer, addBtn);

        table = new TableView<>();
        DashboardView.styleTable(table);
        table.setPrefHeight(460);

        TableColumn<DRIVER, String> idCol  = DashboardView.col("ID",      80,  d -> String.valueOf(d.getDriverID()));
        TableColumn<DRIVER, String> nmCol  = DashboardView.col("Name",    180, d -> d.getName());
        TableColumn<DRIVER, String> licCol = DashboardView.col("License", 160, d -> d.getLicenseNumber());
        TableColumn<DRIVER, String> vehCol = DashboardView.col("Assigned Vehicle", 180, d -> {
            for (VEHICLE v : admin.getVehicles())
                if (v.getAssignedDriver() != null && v.getAssignedDriver().getDriverID() == d.getDriverID())
                    return v.getVehicleNumber();
            return "Not assigned";
        });

        TableColumn<DRIVER, Void> actCol = new TableColumn<>("Actions");
        actCol.setPrefWidth(100);
        actCol.setCellFactory(col -> new TableCell<>() {
            final Button del = VehicleView.dangerBtn("Remove");
            { del.setOnAction(e -> {
                  DRIVER d = getTableView().getItems().get(getIndex());
                  Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Remove driver " + d.getName() + "?", ButtonType.YES, ButtonType.NO);
                  a.showAndWait().ifPresent(bt -> {
                      if (bt == ButtonType.YES) {
                          admin.getVehicles().forEach(v -> { if (v.getAssignedDriver() != null && v.getAssignedDriver().getDriverID() == d.getDriverID()) v.assignDriver(null); });
                          admin.removeDriver(d); refresh();
                      }
                  });
              });
              HBox box = new HBox(del); box.setAlignment(Pos.CENTER); setGraphic(box);
            }
            @Override protected void updateItem(Void item, boolean empty) { super.updateItem(item, empty); setGraphic(empty ? null : getGraphic()); }
        });

        table.getColumns().addAll(idCol, nmCol, licCol, vehCol, actCol);
        refresh();

        content.getChildren().addAll(header, table);
        ScrollPane sp = new ScrollPane(content);
        sp.setFitToWidth(true);
        sp.setStyle("-fx-background-color: #0D1117; -fx-background: #0D1117;");
        return sp;
    }

    private void refresh() { table.getItems().setAll(admin.getDrivers()); }

    private void showAddDialog() {
        Dialog<ButtonType> dlg = VehicleView.styledDialog("Add Driver");
        GridPane grid = VehicleView.formGrid();

        TextField nameF = VehicleView.formField("Ali Hassan");
        TextField licF  = VehicleView.formField("LHR-2024-001");

        ComboBox<String> vehCB = new ComboBox<>();
        vehCB.getItems().add("— None —");
        admin.getVehicles().forEach(v -> vehCB.getItems().add(v.getVehicleNumber()));
        vehCB.setValue("— None —");
        VehicleView.styleCombo(vehCB);

        grid.addRow(0, VehicleView.formLabel("Full Name"), nameF);
        grid.addRow(1, VehicleView.formLabel("License No."), licF);
        grid.addRow(2, VehicleView.formLabel("Assign to Vehicle"), vehCB);

        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        VehicleView.styleDialogButtons(dlg);

        Optional<ButtonType> res = dlg.showAndWait();
        if (res.isPresent() && res.get() == ButtonType.OK) {
            String name = nameF.getText().trim();
            String lic  = licF.getText().trim();
            if (name.isEmpty() || lic.isEmpty()) { VehicleView.showError("Name and license are required."); return; }
            DRIVER d = new DRIVER(nextID++, name, lic);
            admin.addDriver(d);
            String sel = vehCB.getValue();
            if (sel != null && !sel.equals("— None —")) {
                admin.getVehicles().stream()
                     .filter(v -> v.getVehicleNumber().equals(sel))
                     .findFirst().ifPresent(v -> v.assignDriver(d));
            }
            refresh();
        }
    }
}
