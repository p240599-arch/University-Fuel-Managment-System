package views;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import models.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class FuelView {

    private final ADMIN admin;
    private TableView<FuelRow> table;
    private int nextID = 400;

    public FuelView(ADMIN admin) { this.admin = admin; }

    record FuelRow(int recordID, String vehicle, float amount, String date, String driver) {}

    public ScrollPane build() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(28));
        content.setStyle("-fx-background-color: #0D1117;");

        HBox header = new HBox(12);
        header.setAlignment(Pos.CENTER_LEFT);
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
        Button addBtn = VehicleView.primaryBtn("+ Add Fuel Record");
        addBtn.setOnAction(e -> showAddDialog());
        header.getChildren().addAll(VehicleView.sectionLabel("FUEL RECORDS"), spacer, addBtn);

        table = new TableView<>();
        DashboardView.styleTable(table);
        table.setPrefHeight(460);

        TableColumn<FuelRow, String> idCol  = DashboardView.col("Record ID", 90,  r -> String.valueOf(r.recordID()));
        TableColumn<FuelRow, String> vehCol = DashboardView.col("Vehicle",   160, r -> r.vehicle());
        TableColumn<FuelRow, String> amtCol = DashboardView.col("Amount (L)",120, r -> String.format("%.1f L", r.amount()));
        TableColumn<FuelRow, String> dtCol  = DashboardView.col("Date",      130, r -> r.date());
        TableColumn<FuelRow, String> drvCol = DashboardView.col("Driver",    160, r -> r.driver());

        table.getColumns().addAll(idCol, vehCol, amtCol, dtCol, drvCol);
        refresh();

        content.getChildren().addAll(header, table);
        ScrollPane sp = new ScrollPane(content);
        sp.setFitToWidth(true);
        sp.setStyle("-fx-background-color: #0D1117; -fx-background: #0D1117;");
        return sp;
    }

    private void refresh() {
        List<FuelRow> rows = new ArrayList<>();
        for (VEHICLE v : admin.getVehicles()) {
            String drvName = v.getAssignedDriver() != null ? v.getAssignedDriver().getName() : "—";
            for (FUEL_RECORD fr : v.getFuelRecords())
                rows.add(new FuelRow(fr.getRecordID(), v.getVehicleNumber(), fr.getFuelAmount(), fr.getDate(), drvName));
        }
        table.getItems().setAll(rows);
    }

    private void showAddDialog() {
        if (admin.getVehicles().isEmpty()) { VehicleView.showError("No vehicles registered."); return; }

        Dialog<ButtonType> dlg = VehicleView.styledDialog("Add Fuel Record");
        GridPane grid = VehicleView.formGrid();

        ComboBox<String> vehCB = new ComboBox<>();
        admin.getVehicles().forEach(v -> vehCB.getItems().add(v.getVehicleNumber()));
        vehCB.getSelectionModel().selectFirst();
        VehicleView.styleCombo(vehCB);

        TextField amtF  = VehicleView.formField("45.0");
        DatePicker datePicker = new DatePicker(LocalDate.now());
        datePicker.setStyle("-fx-background-color: #0D1117; -fx-border-color: #30363D; -fx-border-radius: 5; " +
                            "-fx-background-radius: 5; -fx-font-family: 'Courier New'; -fx-font-size: 12px;");
        datePicker.setPrefWidth(220);

        grid.addRow(0, VehicleView.formLabel("Vehicle"), vehCB);
        grid.addRow(1, VehicleView.formLabel("Amount (L)"), amtF);
        grid.addRow(2, VehicleView.formLabel("Date"), datePicker);

        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        VehicleView.styleDialogButtons(dlg);

        Optional<ButtonType> res = dlg.showAndWait();
        if (res.isPresent() && res.get() == ButtonType.OK) {
            String vehNum = vehCB.getValue();
            String amtStr = amtF.getText().trim();
            LocalDate date = datePicker.getValue();
            if (vehNum == null || amtStr.isEmpty() || date == null) { VehicleView.showError("All fields required."); return; }
            try {
                float amt = Float.parseFloat(amtStr);
                if (amt <= 0) { VehicleView.showError("Amount must be positive."); return; }
                VEHICLE v = admin.getVehicles().stream().filter(x -> x.getVehicleNumber().equals(vehNum)).findFirst().orElse(null);
                if (v == null) return;
                // Check capacity
                if (v.getTotalFuelUsed() + amt > v.getFuelCapacity()) {
                    VehicleView.showError("Exceeds vehicle fuel capacity (" + v.getFuelCapacity() + "L).");
                    return;
                }
                v.addFuelRecord(new FUEL_RECORD(nextID++, amt, date.toString()));
                refresh();
            } catch (NumberFormatException ex) { VehicleView.showError("Amount must be a number."); }
        }
    }
}
