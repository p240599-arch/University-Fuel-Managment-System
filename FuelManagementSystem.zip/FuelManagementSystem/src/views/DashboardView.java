package views;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import models.*;

import java.util.List;

public class DashboardView {

    private final ADMIN admin;
    private final MainLayout layout;

    public DashboardView(ADMIN admin, MainLayout layout) {
        this.admin = admin;
        this.layout = layout;
    }

    public ScrollPane build() {
        VBox content = new VBox(24);
        content.setPadding(new Insets(28, 28, 28, 28));
        content.setStyle("-fx-background-color: #0D1117;");

        content.getChildren().addAll(
            buildStatCards(),
            buildFleetTable()
        );

        ScrollPane sp = new ScrollPane(content);
        sp.setFitToWidth(true);
        sp.setStyle("-fx-background-color: #0D1117; -fx-background: #0D1117;");
        return sp;
    }

    private GridPane buildStatCards() {
        GridPane grid = new GridPane();
        grid.setHgap(14);
        grid.setVgap(14);

        List<VEHICLE> vehicles = admin.getVehicles();
        List<DRIVER>  drivers  = admin.getDrivers();

        int totalVehicles = vehicles.size();
        int totalDrivers  = drivers.size();
        float totalFuel   = 0;
        int totalTrips    = 0;
        for (VEHICLE v : vehicles) {
            totalFuel  += v.getTotalFuelUsed();
            totalTrips += v.getTrips().size();
        }

        grid.add(statCard("🚗", "Total Vehicles", String.valueOf(totalVehicles), "#58A6FF", "Fleet registered"), 0, 0);
        grid.add(statCard("👤", "Total Drivers",  String.valueOf(totalDrivers),  "#3FB950", "Active personnel"), 1, 0);
        grid.add(statCard("⛽", "Fuel Consumed",  String.format("%.1fL", totalFuel), "#F0A500", "Total recorded"), 2, 0);
        grid.add(statCard("🗺", "Trips Logged",   String.valueOf(totalTrips),    "#BC8CFF", "Distance covered"), 3, 0);

        ColumnConstraints cc = new ColumnConstraints();
        cc.setPercentWidth(25);
        grid.getColumnConstraints().addAll(cc, cc, cc, cc);
        return grid;
    }

    private VBox statCard(String icon, String label, String value, String color, String sub) {
        VBox card = new VBox(8);
        card.setPadding(new Insets(18));
        card.setStyle("-fx-background-color: #161B22; -fx-border-color: #30363D; -fx-border-radius: 8; -fx-background-radius: 8;");

        Label lbl = new Label(label);
        lbl.setStyle("-fx-font-size: 10px; -fx-text-fill: #8B949E; -fx-font-family: 'Courier New'; -fx-letter-spacing: 1;");

        Label val = new Label(value);
        val.setStyle("-fx-font-size: 30px; -fx-font-weight: bold; -fx-text-fill: " + color + "; -fx-font-family: 'Courier New';");

        Label subLbl = new Label(sub);
        subLbl.setStyle("-fx-font-size: 10px; -fx-text-fill: #484F58; -fx-font-family: 'Courier New';");

        card.getChildren().addAll(lbl, val, subLbl);
        return card;
    }

    private VBox buildFleetTable() {
        VBox section = new VBox(12);

        Label title = new Label("FLEET STATUS");
        title.setStyle("-fx-font-size: 11px; -fx-font-weight: bold; -fx-text-fill: #8B949E; -fx-font-family: 'Courier New'; -fx-letter-spacing: 2;");

        TableView<VEHICLE> table = new TableView<>();
        styleTable(table);
        table.setPrefHeight(280);

        TableColumn<VEHICLE, String> numCol   = col("Registration", 160, v -> v.getVehicleNumber());
        TableColumn<VEHICLE, String> typeCol  = col("Type", 90,  v -> v.getVehicleType());
        TableColumn<VEHICLE, String> drvCol   = col("Driver", 160, v -> v.getAssignedDriver() != null ? v.getAssignedDriver().getName() : "—");
        TableColumn<VEHICLE, String> fuelCol  = col("Fuel Used", 110, v -> String.format("%.1fL", v.getTotalFuelUsed()));
        TableColumn<VEHICLE, String> tripCol  = col("Trips", 80,  v -> String.valueOf(v.getTrips().size()));
        TableColumn<VEHICLE, String> capCol   = col("Capacity", 100, v -> v.getFuelCapacity() + "L");

        table.getColumns().addAll(numCol, typeCol, drvCol, fuelCol, tripCol, capCol);
        table.getItems().addAll(admin.getVehicles());

        section.getChildren().addAll(title, table);
        return section;
    }

    static <T> TableColumn<T, String> col(String name, double width, java.util.function.Function<T, String> getter) {
        TableColumn<T, String> c = new TableColumn<>(name);
        c.setPrefWidth(width);
        c.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(getter.apply(p.getValue())));
        c.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 12px;");
        return c;
    }

    static void styleTable(TableView<?> table) {
        table.setStyle(
            "-fx-background-color: #161B22; -fx-border-color: #30363D; " +
            "-fx-border-radius: 8; -fx-background-radius: 8; " +
            "-fx-table-cell-border-color: #21262D;"
        );
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }
}
