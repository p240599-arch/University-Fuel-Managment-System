package views;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import models.ADMIN;

public class ReportView {

    private final ADMIN admin;

    public ReportView(ADMIN admin) { this.admin = admin; }

    public VBox build() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(28));
        content.setStyle("-fx-background-color: #0D1117;");

        HBox header = new HBox(12);
        header.setAlignment(Pos.CENTER_LEFT);
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
        Button genBtn = VehicleView.primaryBtn("Generate Report");
        header.getChildren().addAll(VehicleView.sectionLabel("SYSTEM REPORT"), spacer, genBtn);

        // Info banner
        Label info = new Label("ℹ  Reports include all vehicles, fuel records, and trip summaries. Click Generate to compile.");
        info.setStyle("-fx-background-color: rgba(88,166,255,0.1); -fx-border-color: rgba(88,166,255,0.25); " +
                      "-fx-border-radius: 6; -fx-background-radius: 6; " +
                      "-fx-text-fill: #58A6FF; -fx-font-family: 'Courier New'; -fx-font-size: 11px; -fx-padding: 10 14;");
        info.setWrapText(true);

        // Report text area
        TextArea reportArea = new TextArea("// Click \"Generate Report\" to compile the full system report...");
        reportArea.setEditable(false);
        reportArea.setWrapText(true);
        reportArea.setPrefHeight(420);
        reportArea.setStyle(
            "-fx-background-color: #161B22; -fx-border-color: #30363D; -fx-border-radius: 8; " +
            "-fx-background-radius: 8; -fx-text-fill: #8B949E; " +
            "-fx-font-family: 'Courier New'; -fx-font-size: 12px; -fx-control-inner-background: #161B22;"
        );
        VBox.setVgrow(reportArea, Priority.ALWAYS);

        genBtn.setOnAction(e -> {
            String report = admin.generateReport();
            reportArea.setText(report);
            reportArea.setStyle(
                "-fx-background-color: #161B22; -fx-border-color: #30363D; -fx-border-radius: 8; " +
                "-fx-background-radius: 8; -fx-text-fill: #E6EDF3; " +
                "-fx-font-family: 'Courier New'; -fx-font-size: 12px; -fx-control-inner-background: #161B22;"
            );
        });

        content.getChildren().addAll(header, info, reportArea);
        return content;
    }
}
