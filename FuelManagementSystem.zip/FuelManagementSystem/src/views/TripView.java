package views;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import models.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TripView {

    private final ADMIN admin;
    private TableView<TripRow> table;
    private int nextID = 500;

    public TripView(ADMIN admin) { this.admin = admin; }

    record TripRow(int tripID, String vehicle, String from, String to, float dist, TRIP tripRef) {}

    public ScrollPane build() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(28));
        content.setStyle("-fx-background-color: #0D1117;");

        HBox header = new HBox(12);
        header.setAlignment(Pos.CENTER_LEFT);
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
        Button addBtn = VehicleView.primaryBtn("+ Record Trip");
        addBtn.setOnAction(e -> showAddDialog());
        header.getChildren().addAll(VehicleView.sectionLabel("TRIP LOGS"), spacer, addBtn);

        table = new TableView<>();
        DashboardView.styleTable(table);
        table.setPrefHeight(460);

        TableColumn<TripRow, String> idCol   = DashboardView.col("ID",           80,  r -> String.valueOf(r.tripID()));
        TableColumn<TripRow, String> vehCol  = DashboardView.col("Vehicle",      150, r -> r.vehicle());
        TableColumn<TripRow, String> fromCol = DashboardView.col("From",         160, r -> r.from());
        TableColumn<TripRow, String> toCol   = DashboardView.col("To",           160, r -> r.to());
        TableColumn<TripRow, String> distCol = DashboardView.col("Distance (km)",120, r -> String.format("%.1f km", r.dist()));

        TableColumn<TripRow, Void> actCol = new TableColumn<>("Actions");
        actCol.setPrefWidth(100);
        actCol.setCellFactory(col -> new TableCell<>() {
            final Button editBtn = VehicleView.smallBtn("Edit");
            { editBtn.setOnAction(e -> showEditDialog(getTableView().getItems().get(getIndex())));
              HBox box = new HBox(editBtn); box.setAlignment(Pos.CENTER); setGraphic(box); }
            @Override protected void updateItem(Void item, boolean empty) { super.updateItem(item, empty); setGraphic(empty ? null : getGraphic()); }
        });

        table.getColumns().addAll(idCol, vehCol, fromCol, toCol, distCol, actCol);
        refresh();

        content.getChildren().addAll(header, table);
        ScrollPane sp = new ScrollPane(content);
        sp.setFitToWidth(true);
        sp.setStyle("-fx-background-color: #0D1117; -fx-background: #0D1117;");
        return sp;
    }

    private void refresh() {
        List<TripRow> rows = new ArrayList<>();
        for (VEHICLE v : admin.getVehicles())
            for (TRIP t : v.getTrips())
                rows.add(new TripRow(t.getTripID(), v.getVehicleNumber(), t.getStartLocation(), t.getDestination(), t.getDistance(), t));
        table.getItems().setAll(rows);
    }

    private void showAddDialog() {
        if (admin.getVehicles().isEmpty()) { VehicleView.showError("No vehicles registered."); return; }

        Dialog<ButtonType> dlg = VehicleView.styledDialog("Record Trip");
        GridPane grid = VehicleView.formGrid();

        ComboBox<String> vehCB = new ComboBox<>();
        admin.getVehicles().forEach(v -> vehCB.getItems().add(v.getVehicleNumber()));
        vehCB.getSelectionModel().selectFirst();
        VehicleView.styleCombo(vehCB);

        TextField fromF = VehicleView.formField("Main Campus");
        TextField toF   = VehicleView.formField("City Hospital");
        TextField distF = VehicleView.formField("12.5");

        grid.addRow(0, VehicleView.formLabel("Vehicle"), vehCB);
        grid.addRow(1, VehicleView.formLabel("From"), fromF);
        grid.addRow(2, VehicleView.formLabel("To"), toF);
        grid.addRow(3, VehicleView.formLabel("Distance (km)"), distF);

        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        VehicleView.styleDialogButtons(dlg);

        Optional<ButtonType> res = dlg.showAndWait();
        if (res.isPresent() && res.get() == ButtonType.OK) {
            String from = fromF.getText().trim(), to = toF.getText().trim(), distStr = distF.getText().trim();
            if (from.isEmpty() || to.isEmpty() || distStr.isEmpty()) { VehicleView.showError("All fields required."); return; }
            try {
                float dist = Float.parseFloat(distStr);
                VEHICLE v = admin.getVehicles().stream().filter(x -> x.getVehicleNumber().equals(vehCB.getValue())).findFirst().orElse(null);
                if (v == null) return;
                TRIP t = new TRIP(nextID++, from, to, dist);
                t.recordTrip();
                v.addTrip(t);
                refresh();
            } catch (NumberFormatException ex) { VehicleView.showError("Distance must be a number."); }
        }
    }

    private void showEditDialog(TripRow row) {
        Dialog<ButtonType> dlg = VehicleView.styledDialog("Edit Trip");
        GridPane grid = VehicleView.formGrid();

        TextField fromF = VehicleView.formField(""); fromF.setText(row.from());
        TextField toF   = VehicleView.formField(""); toF.setText(row.to());
        TextField distF = VehicleView.formField(""); distF.setText(String.valueOf(row.dist()));

        grid.addRow(0, VehicleView.formLabel("From"), fromF);
        grid.addRow(1, VehicleView.formLabel("To"), toF);
        grid.addRow(2, VehicleView.formLabel("Distance (km)"), distF);

        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        VehicleView.styleDialogButtons(dlg);

        Optional<ButtonType> res = dlg.showAndWait();
        if (res.isPresent() && res.get() == ButtonType.OK) {
            String from = fromF.getText().trim(), to = toF.getText().trim(), distStr = distF.getText().trim();
            if (from.isEmpty() || to.isEmpty() || distStr.isEmpty()) { VehicleView.showError("All fields required."); return; }
            try {
                row.tripRef().setStartLocation(from);
                row.tripRef().setDestination(to);
                row.tripRef().setDistance(Float.parseFloat(distStr));
                row.tripRef().updateTrip();
                refresh();
            } catch (NumberFormatException ex) { VehicleView.showError("Distance must be a number."); }
        }
    }
}
