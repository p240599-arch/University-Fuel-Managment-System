package views;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
import models.ADMIN;

public class LoginScreen {

    private final Stage stage;
    private static final ADMIN SYSTEM_ADMIN = new ADMIN(1, "admin", "pass123");

    // Seed demo data
    static {
        models.VEHICLE v1 = new models.VEHICLE(101, "UNI-BUS-01", "Bus", 120f);
        models.VEHICLE v2 = new models.VEHICLE(102, "UNI-VAN-02", "Van",  60f);
        models.VEHICLE v3 = new models.VEHICLE(103, "UNI-CAR-03", "Car",  45f);
        models.DRIVER  d1 = new models.DRIVER(201, "Ali Hassan",   "LHR-2021-001");
        models.DRIVER  d2 = new models.DRIVER(202, "Sara Khan",    "ISB-2019-045");
        models.DRIVER  d3 = new models.DRIVER(203, "Usman Farooq", "RWP-2022-078");
        v1.assignDriver(d1); v2.assignDriver(d2); v3.assignDriver(d3);
        v1.addFuelRecord(new models.FUEL_RECORD(301, 85.5f, "2025-05-01"));
        v1.addFuelRecord(new models.FUEL_RECORD(304, 50.0f, "2025-05-05"));
        v2.addFuelRecord(new models.FUEL_RECORD(302, 40.0f, "2025-05-02"));
        v3.addFuelRecord(new models.FUEL_RECORD(303, 30.0f, "2025-05-03"));
        v1.addTrip(new models.TRIP(401, "Main Campus", "City Hospital", 12.5f));
        v1.addTrip(new models.TRIP(402, "Boys Hostel",  "Main Gate",     2.0f));
        v3.addTrip(new models.TRIP(403, "Main Campus",  "Airport",      25.0f));
        SYSTEM_ADMIN.addVehicle(v1); SYSTEM_ADMIN.addVehicle(v2); SYSTEM_ADMIN.addVehicle(v3);
        SYSTEM_ADMIN.addDriver(d1);  SYSTEM_ADMIN.addDriver(d2);  SYSTEM_ADMIN.addDriver(d3);
    }

    public static ADMIN getAdmin() { return SYSTEM_ADMIN; }

    public LoginScreen(Stage stage) {
        this.stage = stage;
    }

    public void show() {
        stage.setTitle("University Fuel Management System");
        stage.setMinWidth(900);
        stage.setMinHeight(620);

        // Root split: left brand panel + right form panel
        HBox root = new HBox();
        root.setStyle("-fx-background-color: #0D1117;");

        // ── LEFT BRAND PANEL ──────────────────────────────────────
        VBox leftPanel = new VBox(16);
        leftPanel.setPrefWidth(400);
        leftPanel.setAlignment(Pos.CENTER);
        leftPanel.setPadding(new Insets(60));
        leftPanel.setStyle("-fx-background-color: #161B22; -fx-border-color: #30363D; -fx-border-width: 0 1 0 0;");

        Label icon = new Label("⛽");
        icon.setStyle("-fx-font-size: 52px;");

        Label brand = new Label("UniFleet");
        brand.setStyle("-fx-font-size: 36px; -fx-font-weight: bold; -fx-text-fill: #F0A500; -fx-font-family: 'Courier New';");

        Label sub = new Label("University Fuel Management System");
        sub.setStyle("-fx-font-size: 12px; -fx-text-fill: #8B949E; -fx-font-family: 'Courier New';");
        sub.setWrapText(true);
        sub.setTextAlignment(TextAlignment.CENTER);

        Separator sep = new Separator();
        sep.setStyle("-fx-background-color: #30363D;");
        sep.setPrefWidth(200);

        VBox features = new VBox(10);
        features.setAlignment(Pos.CENTER_LEFT);
        String[] feats = {"▸  Fleet Vehicle Management", "▸  Driver Assignment & Tracking",
                          "▸  Fuel Record Logging", "▸  Trip History & Reports"};
        for (String f : feats) {
            Label fl = new Label(f);
            fl.setStyle("-fx-font-size: 12px; -fx-text-fill: #58A6FF; -fx-font-family: 'Courier New';");
            features.getChildren().add(fl);
        }

        leftPanel.getChildren().addAll(icon, brand, sub, sep, features);

        // ── RIGHT FORM PANEL ──────────────────────────────────────
        VBox rightPanel = new VBox(20);
        rightPanel.setAlignment(Pos.CENTER);
        rightPanel.setPadding(new Insets(60, 70, 60, 70));
        HBox.setHgrow(rightPanel, Priority.ALWAYS);
        rightPanel.setStyle("-fx-background-color: #0D1117;");

        Label loginTitle = new Label("Welcome back");
        loginTitle.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #E6EDF3; -fx-font-family: 'Courier New';");

        Label loginSub = new Label("Sign in to your admin account");
        loginSub.setStyle("-fx-font-size: 13px; -fx-text-fill: #8B949E; -fx-font-family: 'Courier New';");

        // Username
        Label userLabel = new Label("USERNAME");
        userLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #8B949E; -fx-font-family: 'Courier New'; -fx-letter-spacing: 2;");
        TextField userField = new TextField();
        userField.setPromptText("admin");
        userField.setText("admin");
        styleInput(userField);

        // Password
        Label passLabel = new Label("PASSWORD");
        passLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #8B949E; -fx-font-family: 'Courier New'; -fx-letter-spacing: 2;");
        PasswordField passField = new PasswordField();
        passField.setPromptText("••••••••");
        passField.setText("pass123");
        styleInput(passField);

        // Error label
        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: #F85149; -fx-font-size: 12px; -fx-font-family: 'Courier New';");
        errorLabel.setVisible(false);

        // Login button
        Button loginBtn = new Button("AUTHENTICATE →");
        loginBtn.setPrefWidth(Double.MAX_VALUE);
        loginBtn.setPrefHeight(44);
        loginBtn.setStyle(
            "-fx-background-color: #F0A500; -fx-text-fill: #0D1117; " +
            "-fx-font-weight: bold; -fx-font-size: 13px; " +
            "-fx-font-family: 'Courier New'; -fx-cursor: hand; " +
            "-fx-background-radius: 6;"
        );
        loginBtn.setOnMouseEntered(e -> loginBtn.setStyle(
            "-fx-background-color: #D4941A; -fx-text-fill: #0D1117; " +
            "-fx-font-weight: bold; -fx-font-size: 13px; " +
            "-fx-font-family: 'Courier New'; -fx-cursor: hand; " +
            "-fx-background-radius: 6;"
        ));
        loginBtn.setOnMouseExited(e -> loginBtn.setStyle(
            "-fx-background-color: #F0A500; -fx-text-fill: #0D1117; " +
            "-fx-font-weight: bold; -fx-font-size: 13px; " +
            "-fx-font-family: 'Courier New'; -fx-cursor: hand; " +
            "-fx-background-radius: 6;"
        ));

        Label hint = new Label("Default: admin / pass123");
        hint.setStyle("-fx-font-size: 11px; -fx-text-fill: #30363D; -fx-font-family: 'Courier New';");

        // Login action
        Runnable doLogin = () -> {
            String u = userField.getText().trim();
            String p = passField.getText();
            if (SYSTEM_ADMIN.authenticate(u, p)) {
                new MainLayout(stage, SYSTEM_ADMIN).show();
            } else {
                errorLabel.setText("✗  Invalid username or password");
                errorLabel.setVisible(true);
                passField.clear();
            }
        };
        loginBtn.setOnAction(e -> doLogin.run());
        passField.setOnAction(e -> doLogin.run());

        VBox userGroup = new VBox(6, userLabel, userField);
        VBox passGroup = new VBox(6, passLabel, passField);

        rightPanel.getChildren().addAll(loginTitle, loginSub, userGroup, passGroup,
                                        errorLabel, loginBtn, hint);

        root.getChildren().addAll(leftPanel, rightPanel);

        Scene scene = new Scene(root, 860, 560);
        stage.setScene(scene);
        stage.show();
    }

    private void styleInput(TextField tf) {
        tf.setPrefHeight(42);
        tf.setStyle(
            "-fx-background-color: #161B22; -fx-border-color: #30363D; " +
            "-fx-border-radius: 6; -fx-background-radius: 6; " +
            "-fx-text-fill: #E6EDF3; -fx-prompt-text-fill: #484F58; " +
            "-fx-font-family: 'Courier New'; -fx-font-size: 13px; -fx-padding: 0 12;"
        );
        tf.focusedProperty().addListener((obs, o, n) -> {
            if (n) tf.setStyle(
                "-fx-background-color: #161B22; -fx-border-color: #F0A500; " +
                "-fx-border-radius: 6; -fx-background-radius: 6; " +
                "-fx-text-fill: #E6EDF3; -fx-prompt-text-fill: #484F58; " +
                "-fx-font-family: 'Courier New'; -fx-font-size: 13px; -fx-padding: 0 12;"
            );
            else tf.setStyle(
                "-fx-background-color: #161B22; -fx-border-color: #30363D; " +
                "-fx-border-radius: 6; -fx-background-radius: 6; " +
                "-fx-text-fill: #E6EDF3; -fx-prompt-text-fill: #484F58; " +
                "-fx-font-family: 'Courier New'; -fx-font-size: 13px; -fx-padding: 0 12;"
            );
        });
    }
}
